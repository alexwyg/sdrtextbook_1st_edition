clear;
clc;

% sv are signal vectors
sv(1,:)=;
sv(2,:)=;
sv(3,:)=;
sv(4,:)=;

% E(i) is the energy

% Accumulator and subtraction

% Select largest

% Plot
