clear;
clc;
number=100;     % total transmission time (300s)/each signal duration (3s)

% randomly choose one of the four equiprobable signals
% 1000 samples per second means 3000 samples per signal

% zero mean white Gaussian noise of variance 0.5 added

% Define the orthonormal functions {fm(t)}

% Integration to get observation vector (ov)

% Plot
